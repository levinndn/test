﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    Data data = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string query = "select*from hang";
            this.DataList1.DataSource= data.getData(query);
            this.DataList1.DataBind();
        }
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        string mahang = ((LinkButton)sender).CommandArgument;
        Context.Items["mh"] = mahang;
        Server.Transfer("mathangchitiet.aspx");
    }
}