﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    Data data = new Data();
    DataTable dt;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string mahang = Context.Items["mh"].ToString();
            string query = "select* from hang where mahang='" + mahang + "'";
            this.DataList1.DataSource = data.getData(query);
            this.DataBind();
        }
       
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Button mua = ((Button)sender);
        string mahang = mua.CommandArgument;
        DataListItem item = (DataListItem)mua.Parent;
        string soluong = ((TextBox)item.FindControl("TextBox1")).Text;
        string query = "select*from hoadon where mahang='"+mahang+"'";
        dt = data.getData(query);
        if (dt.Rows.Count != 0)
        {
            query = "update hoadon set soluong=soluong+'" + soluong + "' where mahang='" + mahang + "'";
        }
        else
        {
            query = "insert into hoadon values('" + mahang + "','" + soluong + "')";
        }
        data.upDate(query);
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Server.Transfer("giohang.aspx");
    }
}