﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    Data data = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack) return;
        if (!IsPostBack)
        {
            docDL();
        }
    }

    public void docDL()
    {
        string query = "select tenhang,dongia,hoadon.mahang,soluong,soluong*dongia as thanhtien from hang,hoadon where hoadon.mahang=hang.mahang";
        DataTable dt = new DataTable();
        double thanhtien = 0;
        dt = data.getData(query);
        this.GridView1.DataSource =dt; 
        this.GridView1.DataBind();
        foreach(DataRow row in dt.Rows)//Lay du lieu cua 1 hang
        {
            thanhtien = +Convert.ToDouble(row["thanhtien"]); 
        }
        this.Label1.Text = thanhtien.ToString();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Button sua = ((Button)sender);
        string mahang = sua.CommandArgument;
        GridViewRow item = (GridViewRow)sua.Parent.Parent;
        string soluong = ((TextBox)item.FindControl("TextBox1")).Text;
        string query = "update hoadon set soluong='"+soluong+"' where mahang='"+mahang+"'";
        data.upDate(query);
        docDL();
    }

    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        string mahang = ((LinkButton)sender).CommandArgument;
        string query = "delete hoadon where mahang='"+mahang+"'";
        data.upDate(query);
        docDL();
    }
}