﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Data
/// </summary>
public class Data
{
    SqlConnection cn;
    DataTable dt=new DataTable();
    public Data()
    {
        string strcn = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Admin\source\repos\WebSite3\App_Data\Database.mdf;Integrated Security=True";
        cn = new SqlConnection(strcn);
    }

    public DataTable getData(string query)
    {
        SqlDataAdapter da = new SqlDataAdapter(query, cn);
        da.Fill(dt);
        return dt;
    }

    public void upDate(string query)
    {
        cn.Open();
        SqlCommand command = new SqlCommand(query, cn);
        command.ExecuteNonQuery();
        cn.Close();
    }

}